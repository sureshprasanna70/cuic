<html>
<head>
<link href='http://fonts.googleapis.com/css?family=Sorts+Mill+Goudy' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
<link rel="stylesheet" type="text/css" href="css/style.css">


<title>
	CUIC|FACULTY
</title>
</head>
<body>
<?php include('menu.php');?>
<div class="row">
  
  
	
    <div class="span12">
      
	<address>
    <br>
    <img class="cons" src="img/mj.jpg"  width="75" height="50"/>
	  <strong>Dr.P. MANNAR JAWAHAR</strong><br>
  		Professor<br>
  	 	<abbr title="Phone">P:</abbr>(044) 2235 8999<br>
      <br>
 	</address>
 </div>
	</div>
  
<div class="row">
<div class="span12">
	
	<address >
    <br>
    <img class="cons" src="img/tj.jpg"  width="75" height="50"/>
  <strong>Dr. T. THYAGARAJAN</strong><br>
  	Director<br>
  <abbr title="Phone">P:</abbr>(044)-2235 8989  94441 04850
<br>
<br>
  </address>
</div>
</div>
<br>
<div class="row">
<div class="span12">
	<address>
    <br>
    <img class="cons" src="img/ac.jpg"  width="75" height="50"/>
  <strong>Dr. K.ARUNACHALAM</strong><br>
  	Deputy Director<br>
  	<abbr title="Phone">P:</abbr> (044)-2235 8991 <br>98843 45564
    <br>
    <br>
  </address>
</div>
</div>
<div class="row">
<div class="span12">
	<address>
    <br>
    <img class="cons" src="img/bose.jpg"  width="75" height="50"/>
  <strong>Dr. S.BOSE</strong><br>
  	Deputy Director<br>
  	<abbr title="Phone">P:</abbr> 2235 8992 <br>
98402 77262<br>
<br>
  </address>
</div>
</div>

</body>
</html>