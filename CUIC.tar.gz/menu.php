<br>
<div class="banner">
<h1>
	
	<img src="img/banner.png" width="1268" height="auto"/>
	
</h1>
</div>
<br>
<nav class="top-bar">
<ul class="nav nav-tabs">
	<li>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
	<li><a href="http://www.annauiniv.edu">Home</a>
	<li><a href="index.php">About Us</a></li>
	<li><a href="activity.php">Activities</a></li>
	<li><a href="faculty.php">Faculty</a></li>
	<li><a href="company.php">Companies Visited</a></li>
	<li><a href="stat.php">Placement Statistics</a></li>
	<li><a href="#">IAS</a></li>
	<li><a href="gallery.php">Gallery</a></li>
	<li><a href="">Program</a></li>
	<li><a href="contact.php">Contact Us</a></li>
</ul>
</nav>
	


	


	


