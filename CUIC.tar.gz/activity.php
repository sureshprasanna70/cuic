<html>
<head>
<link href='http://fonts.googleapis.com/css?family=Sorts+Mill+Goudy' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic' rel='stylesheet' type='text/css'>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<script src="js/jquery.js"></script>
<title>
	CUIC|ACTIVITIES
</title>
</head>
<body>
<?php include('menu.php');?>
<div class="span12">
<h3 class="title">
On-Going Activities of the C.U.I.C:
</h3>
<ul class="content">
	<li>Arranging Industrial Visits for Students</li>
	<li>Enabling the students to secure Project Internship</li>
	<li>Fecilitating Research Fellowships from industries</li>
<li>Arranging Inplant Training for students during Summer / Winter Vacation</li>
<li>Developed different Monographs and Modlies to suit the needs of the industries.</li>
<li>Enabling the students to get placed in reputed Companies with decent Cost to the Company (CTC)</li>
<li>Conducting Tamil Nadu State Level Placement Programme for the benefit of all the colleges under Anna University with Chennai, Madurai, Coimbatore, Salem and Trichy as nodal centres</li>
<li>Conducting Soft Skill Development and Competency Building Programmes to the students to increase their employability sklls.</li>

</ul>
</body>
</html>