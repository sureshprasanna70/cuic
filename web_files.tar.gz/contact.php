<html>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-responsive.css">
<link href='http://fonts.googleapis.com/css?family=Sorts+Mill+Goudy' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Source+Sans+Pro:400,400italic' rel='stylesheet' type='text/css'>
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
<head>
	<title>CUIC|CONTACT</title>
</head>
<body>
<?php include('menu.php');?>
<div class="row">
	
	<address >
		
    
  	<strong>Dr. T. THYAGARAJAN</strong><br>

    	
    
  	Director<br>
  	Centre for University-Industry Collaboration<br>
	Anna University Chennai<br>
	Sardar Patel Road<br>
	Chennai - 600 025<br>
  <abbr title="Phone">P:</abbr> (044)-22200599,(044)-22358989<br>
  cuic@annauiniv.edu
</address>

</div>
</body>
</html>